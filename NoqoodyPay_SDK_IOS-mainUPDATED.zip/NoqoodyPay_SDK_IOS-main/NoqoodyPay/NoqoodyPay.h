//
//  NoqoodyPay.h
//  NoqoodyPay
//
//  Created by Hussam Elsadany on 09/08/2021.
//

#import <Foundation/Foundation.h>

//! Project version number for NoqoodyPay.
FOUNDATION_EXPORT double NoqoodyPayVersionNumber;

//! Project version string for NoqoodyPay.
FOUNDATION_EXPORT const unsigned char NoqoodyPayVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <NoqoodyPay/PublicHeader.h>


